# -*- coding: utf-8 -*-
from . import tipo_comprobante
from . import account_move
from . import pos_order
from . import res_partner
