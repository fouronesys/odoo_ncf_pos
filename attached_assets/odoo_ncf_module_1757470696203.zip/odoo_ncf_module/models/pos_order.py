# -*- coding: utf-8 -*-
# Archivo vacío - funcionalidad POS movida a módulo separado
